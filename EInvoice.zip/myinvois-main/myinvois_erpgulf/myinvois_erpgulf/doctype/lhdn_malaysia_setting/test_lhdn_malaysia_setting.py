# Copyright (c) 2024, ERPGulf and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestLHDNMalaysiaSetting(FrappeTestCase):
	pass
